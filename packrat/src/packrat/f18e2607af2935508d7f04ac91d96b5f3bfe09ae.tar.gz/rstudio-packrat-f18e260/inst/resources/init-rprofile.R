#### -- Packrat Autoloader (version 0.4.9-2) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
